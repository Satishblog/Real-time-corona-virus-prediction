from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import pickle
app = Flask(__name__)


#open a file, where you want to store the data
file = open('model.pkl','rb')
clf = pickle.load(file)
file.close()
@app.route("/", methods=["GET","POST"])
def hello_world():
  if request.method =="POST":
    myDict = request.form
    Fever = int(myDict['Fever'])
    Age = int(myDict['Age'])
    Pain = int(myDict['Pain'])
    RunnyNose = int(myDict['Runny Nose'])
    DiffBreath = int(myDict['DiffBreath'])
    Cough = int(myDict['Cough'])

    #code for inference
    Inputfeature = [Fever, Pain, Age, RunnyNose, DiffBreath, Cough]
    InfProb = clf.predict_proba([Inputfeature])[0][1]
    print(InfProb)
    return render_template('show.html', Inf=round(InfProb*100)) 
  return render_template('index.html') 
  # return "Hello World!" +str(InfProb)



if __name__ == "__main__":
  app.run(debug=True)