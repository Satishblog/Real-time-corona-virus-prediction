  import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pickle

from sklearn.linear_model import LogisticRegression

def data_split(data, ratio):
    np.random.seed(42)
    shuffled = np.random.permutation(len(data))
    test_set_size = int(len(data)* ratio)
    test_indices = shuffled[:test_set_size]
    train_indices = shuffled[test_set_size:]
    return data.iloc[train_indices], data.iloc[test_indices]


if __name__ == "__main__":    
    covid = pd.read_csv('covid.csv')
    train, test = data_split(covid, 0.2)
    X_train = train[['Fever','Body Pain','Age','RunnyNose','DiffBreath','Cough']].to_numpy()
    X_test = test[['Fever','Body Pain','Age','RunnyNose','DiffBreath','Cough']].to_numpy()
    Y_train = train[['Infection-Prob']].to_numpy().reshape(2748,)
    Y_test = test[['Infection-Prob']].to_numpy().reshape(687,)
    clf = LogisticRegression()
    clf.fit(X_train,Y_train)
    #open a file, where you want to store the data
    file = open('model.pkl','wb')
     
    # dump information to that file
    pickle.dump(clf,file)
    file.close()
    Inputfeature = [100,1,40,1,-1,1]
    InfProb = clf.predict_proba([Inputfeature])[0][1]

